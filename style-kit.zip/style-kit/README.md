# Last Rev Style Kit

Portable design system extracted from the Last Rev marketing site. Drop these files into any project to replicate the visual language.

## Architecture

```
style-kit/
  tokens.css          -- Design tokens (CSS custom properties) + dark/light themes
  layout.css          -- Grid utilities, section wrappers, responsive breakpoints
  components.css      -- Glass cards, buttons, badges, pills, inputs, panels
  typography.css      -- Font stacks, heading scales, body text, eyebrows
  effects.css         -- Glass morphism, neon icons, glow backgrounds, animations
  demo.html           -- Kitchen-sink preview of all styles
  README.md           -- This file
```

## Quick Start

```html
<!-- Load in this order -->
<link rel="stylesheet" href="tokens.css">
<link rel="stylesheet" href="typography.css">
<link rel="stylesheet" href="layout.css">
<link rel="stylesheet" href="components.css">
<link rel="stylesheet" href="effects.css">
```

Or import from a single entry point in your framework:
```css
@import './style-kit/tokens.css';
@import './style-kit/typography.css';
@import './style-kit/layout.css';
@import './style-kit/components.css';
@import './style-kit/effects.css';
```

## Design Tokens

All colors, spacing, and theming use CSS custom properties. Override `:root` to rebrand:

```css
:root {
  --accent: #your-brand-color;
  --accent2: #your-brand-color-light;
  --accent-grad: linear-gradient(135deg, #your-brand-color 0%, #your-brand-color-light 100%);
}
```

## Theming

- **Dark mode** (default): tokens in `:root`
- **Light mode**: add `data-theme="light"` to `<html>`

## Breakpoints

CSS custom properties can't be used in `@media`, so use these values directly:

| Name  | Value   | Use                            |
|-------|---------|--------------------------------|
| xs    | 400px   | Tiny phones                    |
| sm    | 480px   | Small phones                   |
| md    | 640px   | Large phones / small tablets   |
| lg    | 768px   | Tablets                        |
| xl    | 1024px  | Small desktops                 |
| 2xl   | 1280px  | Standard desktops              |
| 3xl   | 1600px  | Large desktops                 |
| 4xl   | 1920px  | Ultra-wide                     |

## No Dependencies

- Pure vanilla CSS (no Tailwind, no PostCSS, no preprocessors)
- System fonts only (no font files to bundle)
- No JavaScript required for styling
